#!/usr/bin/env python3

from visualization_msgs.msg import Marker
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PointStamped, Point
from std_msgs.msg import Header
from tf2_ros import TransformListener, Buffer
from tf2_geometry_msgs import do_transform_point
from math import cos, sin, atan2

class LaserScanToPoints:
    
    def __init__(self):

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer)
        self.fixed_frame_id = rospy.get_param('~fixed_frame', 'map')
        self.pub = rospy.Publisher('points', Marker, queue_size=1)
        self.topic_to_subscribe = rospy.get_param('~subsc_topic', '/pioneer/scan')
        self.scan_subscriber = rospy.Subscriber(self.topic_to_subscribe, LaserScan, self.scan_callback)
        print("Starting the LaserScan to points node.")
        
    def scan_callback(self, scan):
    
        marker = Marker()

        marker.header = scan.header
        marker.type = Marker.POINTS
        marker.pose.orientation.w = 1.0
        marker.color.r = 1.0
        marker.color.a = 1.0
        marker.scale.x = 0.1
        marker.scale.y = 0.1

        for i, range_value in enumerate(scan.ranges):
            if(i < scan.range_min or i > scan.range_max): 
                continue

            angle = scan.angle_min + i * scan.angle_increment
       
            point=Point()
            point.x=range_value * cos(angle)
            point.y=range_value * sin(angle)
            point.z=0.0
           
            marker.points.append(point)

        self.pub.publish(marker)

if __name__ == '__main__':
    rospy.init_node('laserscan_to_points')
    laser_scan_to_points = LaserScanToPoints()
    rospy.spin()
