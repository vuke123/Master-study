#!/usr/bin/env python3
import rosbag
import sys
import math
import std_msgs
import lab3_0036530728.msg as mssg

def calculate_distance(pose1, pose2):
    delta_x = pose1.x - pose2.x
    delta_y = pose1.y - pose2.y
    distance = math.sqrt(delta_x**2 + delta_y**2)
    return distance

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f'Usage: {sys.argv[0]} input.bag chase_target_pose_topic')
        sys.exit()

    initial_time = None
    last_time = None
    input_bag_filename = sys.argv[1]
    chase_target_pose_topic = sys.argv[2]
    chaser_status_topic = "/chaser/status"
    chaser_pose_topic = "/chaser/pose"

    output_bag_filename = input_bag_filename.split(".")[0] + "_processed.bag"
    print(f'Processing input bag: {input_bag_filename}')
    
    chaser_pose_prev = None
    total_distance = 0.0

    target_pose = None

    with rosbag.Bag(output_bag_filename, 'w') as output_bag:
        for topic, msg, serialization_time in rosbag.Bag(input_bag_filename, 'r').read_messages(topics=["/turtle1/pose", chase_target_pose_topic]):
            if topic == chase_target_pose_topic:
                target_pose = msg
            else:
                chaser_pose = msg

                if chaser_pose_prev is not None:
                    last_time = (serialization_time - initial_time).to_sec()
                    distance = calculate_distance(chaser_pose, chaser_pose_prev)
                    total_distance += distance
                else:
                    initial_time = serialization_time
                
                chaser_pose_prev = chaser_pose
                output_bag.write(chaser_pose_topic, chaser_pose, serialization_time)
                chaser_status_msg = mssg.ChaserStatus()
                chaser_status_msg.distance_travelled = total_distance

                if target_pose is not None:
                    chaser_status_msg.distance_to_target = calculate_distance(chaser_pose, target_pose)
                else:
                    chaser_status_msg.distance_to_target = -1
                
                output_bag.write(chaser_status_topic, chaser_status_msg, serialization_time)    

    if last_time is not None and last_time > 0:
        average_velocity = total_distance / last_time
        print(f'Chaser turtle statistics:')
        print(f'Covered distance: {total_distance} TurtleSim units')
        print(f'Average velocity: {average_velocity} TurtleSim units/s')
        print(f'Chase session duration: {last_time} s')
        print(f'Wrote {output_bag.get_message_count()} messages to {output_bag_filename}')
    else:
        print('No valid chase session duration found.')
        print(f'Total distance covered by the chaser turtle: {total_distance} units')

