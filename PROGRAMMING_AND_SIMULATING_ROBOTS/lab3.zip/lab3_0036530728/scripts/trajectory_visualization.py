#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Header
from tf2_msgs.msg import TFMessage
import tf2_ros
from visualization_msgs.msg import Marker
import time
from geometry_msgs.msg import Point

class TrajectoryVisualization:
    def __init__(self):

        self.fixed_frame_id = rospy.get_param('~fixed_frame', 'map')
        self.robot_frame_id = rospy.get_param('~robot_frame', 'pioneer/base_link')
        self.pub = rospy.Publisher('robot_positions', Marker, queue_size=1)

        print(f"Starting the trajectory visualization node.fixed_frame_id: {self.fixed_frame_id} robot_frame_id: {self.robot_frame_id}")

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)

        self.timer = rospy.Timer(rospy.Duration(1.0/30.0), self.timer_callback, reset=True)

        self.marker = Marker()
        self.marker.header.frame_id = self.fixed_frame_id
        self.marker.ns = "trajectory"
        self.marker.id = 0
        self.marker.type = Marker.LINE_STRIP
        self.marker.action = Marker.ADD
        self.marker.scale.x = 0.1  
        self.marker.color.a = 1.0
        self.marker.color.r = 1.0
        self.marker.color.g = 0.8
        self.marker.color.b = 2.0
        self.marker.header.stamp = rospy.Time(0)
        self.marker.points = []
        self.marker.pose.orientation.w = 1.0 

        self.last_transform = tf2_ros.TransformStamped()
        self.last_transform.header.stamp = rospy.Time(0)
        self.counter = 0

    def timer_callback(self, event):       
        try:
            transform = self.tf_buffer.lookup_transform(self.robot_frame_id, self.fixed_frame_id, rospy.Time())
        except Exception as ex:
            print(f"Tf exception: {ex}")

        if self.counter == 0:
            self.last_transform = transform
            self.counter = 1   

        if self.last_transform.header.stamp.__gt__(transform.header.stamp):
            self.last_transform = transform
            self.marker.header.stamp = rospy.Time()
            self.marker.points = []
            print("Timestamp has jumped backwards. Clearing the trajectory marker.")

        if self.position_changed(transform):
            point = Point()
            point.x = transform.transform.translation.x
            point.y = transform.transform.translation.y
            point.z = transform.transform.translation.z

            self.marker.points.append(point)
            self.marker.id = transform.header.seq
            self.marker.header = transform.header

            self.pub.publish(self.marker)
            self.last_transform = transform


    def position_changed(self, transform):
        tolerance = 0.0001
        translation_equal = (
        abs(transform.transform.translation.x - self.last_transform.transform.translation.x) > tolerance or
        abs(transform.transform.translation.y - self.last_transform.transform.translation.y) > tolerance or
        abs(transform.transform.translation.z - self.last_transform.transform.translation.z) > tolerance
        )

        return translation_equal 

if __name__ == '__main__':

    rospy.init_node('trajectory_visualization')
    trajectory_visualization = TrajectoryVisualization()
    rospy.spin()
        
