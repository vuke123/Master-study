#!/usr/bin/env python3

import rospy
from turtlesim.msg import Pose
from pynput.mouse import Controller
from geometry_msgs.msg import Twist, Point
from ewmh import EWMH
from collections import namedtuple

class TurtleMouseNode:

    ScreenCoordinate = namedtuple("ScreenCoordinate", ["x", "y"])
    
    def __init__(self):
        self.tm_pose_publisher = rospy.Publisher('turtlemouse_pose', Pose, queue_size=1)
        self.mouse = Controller()
        self.pose = Pose()
        self.window_manager = EWMH()
        
        update_turtlesim_window_position = lambda _: self.recurse_windows(self.window_manager.root)
        self.turtlesim_upperleft_xy = None
        self.turtlesim_size = None
        update_turtlesim_window_position(None)
        
        rospy.Timer(rospy.Duration(1.0/30.0), update_turtlesim_window_position) 
        rospy.Timer(rospy.Duration(1.0/30.0), self.publish_mouse_position)
 
    def run(self):
        rospy.spin()  

    def publish_mouse_position(self, _):
        
        if self.turtlesim_upperleft_xy is None: 
            return
        mouse_xy = TurtleMouseNode.ScreenCoordinate(*self.mouse.position)
        self.pose.x = mouse_xy.x * (11.11/1024)
        self.pose.y = 11.0 - (mouse_xy.y * (11.11/768))
        print(self.pose)
        self.tm_pose_publisher.publish(self.pose)
    
    def recurse_windows(self, window):
        try:
            if window.get_wm_name() == "TurtleSim":
                my_geometry = window.get_geometry()
                parent = window.query_tree().parent
                parent_geometry = parent.get_geometry()
                parent_parent = parent.query_tree().parent
                parent_parent_geometry = parent_parent.get_geometry()
                
                self.turtlesim_upperleft_xy = TurtleMouseNode.ScreenCoordinate(
                    parent_parent_geometry.x + parent_geometry.x + my_geometry.x,
                    parent_parent_geometry.y + parent_geometry.y + my_geometry.y,
                )

                self.turtlesim_size = TurtleMouseNode.ScreenCoordinate(
                    my_geometry.width, my_geometry.height
                )
                return
        except:
            pass
    
        for child in window.query_tree().children:
            self.recurse_windows(child)
    
    
if __name__ == '__main__':
    try:
        rospy.init_node('turtle_mouse_node', anonymous=True)
        tm_node = TurtleMouseNode()
        tm_node.run()

    except rospy.ROSInterruptException:
        pass

