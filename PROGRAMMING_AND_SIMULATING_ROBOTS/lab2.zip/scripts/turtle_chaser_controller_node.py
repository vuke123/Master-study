#!/usr/bin/env python3

from pynput.mouse import Controller
import rospy
import math
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

class TurtleChaserNode:

    def __init__(self):
        self.tc_vel_pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=1)
        self.forward_gain = rospy.get_param('~forward_gain', 1)
        self.angular_gain = rospy.get_param('~angular_gain', 2)
        
        self.pose2 = Pose()
        self.pose = Pose()
        
        self.topic2 = rospy.get_param("~topic2_name", "/turtlemouse_pose")
        rospy.Subscriber(self.topic2, Pose, self.pose2_callback) 
        rospy.Subscriber('/turtle1/pose', Pose, self.t_pose_callback)
        
    def wrap_to_pi(self, angle):
        while angle > math.pi:
            angle -= 2 * math.pi 
        while angle < -math.pi: 
            angle += 2 * math.pi 
        return angle 
       
    def run(self):
        rospy.spin()
        
    def t_pose_callback(self, data): 
        self.pose = data
        vel = Twist()
        vel.linear.x = self.forward_gain * self.calculate_d()
        vel.linear.y = 0
        angle = self.calculate_a()
        vel.angular.z = self.angular_gain * self.wrap_to_pi(angle)
        print(self.calculate_d())
        
        if (self.calculate_d() < 0.3):
            vel.linear.x = 0
            vel.angular.z = 0
            
        self.tc_vel_pub.publish(vel)

        
    def pose2_callback(self, data): 
        self.pose2 = data   	
    	
    def calculate_d(self): 
        d = math.sqrt(pow((self.pose2.x - self.pose.x), 2) + pow((self.pose2.y - self.pose.y), 2))
        return d
    	
    def calculate_a(self):
        a = round(math.atan2(self.pose2.y - self.pose.y, self.pose2.x - self.pose.x) - self.pose.theta, 5) 
        return a 
    
    
if __name__ == '__main__':
    try:
        rospy.init_node('turtle_chaser_node', anonymous=True)
        tc_node = TurtleChaserNode()
        tc_node.run()

    except rospy.ROSInterruptException:
        pass

